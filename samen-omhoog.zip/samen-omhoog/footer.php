<?php
/**
 * Footer template.
 *
 * @package SamenOmhoog
 */

$so_whatsapp = samen_omhoog_opt( 'whatsapp', '31628859553' );
$so_email    = samen_omhoog_opt( 'email', 'info@samenomhoog.nl' );
$so_phone    = samen_omhoog_opt( 'phone', '06-28859553' );
$so_address  = samen_omhoog_opt( 'address', 'Floresstraat 7, 8022 AD Zwolle' );
$so_kvk      = samen_omhoog_opt( 'kvk', '89792807' );
$so_rsin     = samen_omhoog_opt( 'rsin', '865111339' );
$so_agb      = samen_omhoog_opt( 'agb', '98108329' );
?>

<footer class="site-footer">
	<div class="footer-top">
		<div class="footer-brand">
			<?php $so_footer_logo = samen_omhoog_img_src( 'logo.png' ); ?>
			<?php if ( $so_footer_logo ) : ?>
				<div class="footer-logo"><img src="<?php echo esc_url( $so_footer_logo ); ?>" alt="<?php esc_attr_e( 'Samen Omhoog', 'samen-omhoog' ); ?>"></div>
			<?php else : ?>
				<div class="footer-logo">Samen<span>Omhoog</span></div>
			<?php endif; ?>
			<p class="footer-desc"><?php esc_html_e( 'Een ontwikkelplek voor jongeren in Zwolle — de brug tussen thuis, school, straat en werk. Relatie + Ontwikkeling + Werkervaring = Perspectief.', 'samen-omhoog' ); ?></p>
			<div class="footer-contact-chips">
				<span class="footer-chip"><?php echo esc_html( $so_email ); ?></span>
				<span class="footer-chip"><?php echo esc_html( $so_phone ); ?></span>
				<span class="footer-chip"><?php echo esc_html( $so_address ); ?></span>
			</div>
		</div>
		<div>
			<div class="footer-col-title"><?php esc_html_e( "Pagina's", 'samen-omhoog' ); ?></div>
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'footer-links',
						'depth'          => 1,
					)
				);
			} else {
				?>
				<ul class="footer-links">
					<li><a href="#home"><?php esc_html_e( 'Home', 'samen-omhoog' ); ?></a></li>
					<li><a href="#aanbod"><?php esc_html_e( 'Wat we bieden', 'samen-omhoog' ); ?></a></li>
					<li><a href="#team"><?php esc_html_e( 'Wie wij zijn', 'samen-omhoog' ); ?></a></li>
					<li><a href="#contact"><?php esc_html_e( 'Contact', 'samen-omhoog' ); ?></a></li>
				</ul>
				<?php
			}
			?>
		</div>
		<div>
			<div class="footer-col-title"><?php esc_html_e( 'Wat we bieden', 'samen-omhoog' ); ?></div>
			<ul class="footer-links">
				<li><a href="#aanbod"><?php esc_html_e( 'Inloop', 'samen-omhoog' ); ?></a></li>
				<li><a href="#aanbod"><?php esc_html_e( 'Leerwerk & stage', 'samen-omhoog' ); ?></a></li>
				<li><a href="#aanbod"><?php esc_html_e( 'Klas Entree', 'samen-omhoog' ); ?></a></li>
				<li><a href="#aanbod"><?php esc_html_e( 'Zorg & participatie', 'samen-omhoog' ); ?></a></li>
				<li><a href="#aanbod"><?php esc_html_e( 'Jobcoaching', 'samen-omhoog' ); ?></a></li>
			</ul>
		</div>
		<div>
			<div class="footer-col-title"><?php esc_html_e( 'Openingstijden', 'samen-omhoog' ); ?></div>
			<div class="footer-hours">
				<div class="footer-hour"><span class="day"><?php esc_html_e( 'Maandag – Vrijdag', 'samen-omhoog' ); ?></span><span class="time"><?php echo esc_html( samen_omhoog_opt( 'hours_week', '09:00–17:00' ) ); ?></span></div>
				<div class="footer-hour"><span class="day"><?php esc_html_e( 'Avondinloop di &amp; do', 'samen-omhoog' ); ?></span><span class="time"><?php echo esc_html( samen_omhoog_opt( 'hours_evening', '19:00–23:00' ) ); ?></span></div>
				<div class="footer-hour"><span class="day"><?php esc_html_e( 'Za &amp; Zo', 'samen-omhoog' ); ?></span><span class="time"><?php esc_html_e( 'Gesloten', 'samen-omhoog' ); ?></span></div>
			</div>
		</div>
	</div>
	<div class="footer-bottom">
		<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php esc_html_e( 'Stichting Samen Omhoog · Zwolle', 'samen-omhoog' ); ?> · <?php
			/* translators: %1$s KvK number, %2$s RSIN, %3$s AGB code. */
			echo esc_html( sprintf( __( 'KvK %1$s · RSIN %2$s · AGB %3$s', 'samen-omhoog' ), $so_kvk, $so_rsin, $so_agb ) );
		?></span>
		<span><?php esc_html_e( 'ISO 9001 · Klachtenregeling · Coöperatie Boer & Zorg (CBZ) · AVG', 'samen-omhoog' ); ?></span>
	</div>
</footer>

<a class="whatsapp-float" href="<?php echo esc_url( 'https://wa.me/' . $so_whatsapp ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'WhatsApp Samen Omhoog', 'samen-omhoog' ); ?>">
	<svg viewBox="0 0 32 32" fill="currentColor" aria-hidden="true"><path d="M16.04 3C9.44 3 4.07 8.36 4.07 14.96c0 2.11.55 4.17 1.6 5.98L4 29l8.27-1.63a11.9 11.9 0 0 0 5.77 1.47H18.05C24.64 28.84 30 23.48 30 16.88 30 10.3 22.64 3 16.04 3Zm7.04 17.16c-.3.85-1.74 1.63-2.4 1.73-.62.1-1.4.14-2.26-.14-.52-.17-1.2-.39-2.06-.77-3.62-1.56-5.98-5.2-6.16-5.44-.18-.24-1.47-1.96-1.47-3.74s.93-2.65 1.26-3.01c.33-.36.72-.45.96-.45h.69c.22.01.52-.08.81.62.3.72 1.02 2.5 1.11 2.68.09.18.15.39.03.63-.12.24-.18.39-.36.6-.18.21-.38.47-.54.63-.18.18-.37.38-.16.74.21.36.93 1.54 2 2.5 1.37 1.22 2.53 1.6 2.9 1.78.36.18.57.15.78-.09.21-.24.9-1.05 1.14-1.41.24-.36.48-.3.81-.18.33.12 2.1.99 2.46 1.17.36.18.6.27.69.42.09.15.09.87-.21 1.72Z"/></svg>
	<span>WhatsApp</span>
</a>

<?php wp_footer(); ?>
</body>
</html>
